#include"Dictionary.h"

/*
  Date: 03/28/16
  Purpose: Driver program
  Local Var: Objecr DictForCS211 for class Dictionary
*/
int main()
{
        Dictionary  DictForCS211;
        DictForCS211.ProcessTransactionFile();

        return 0;
}
